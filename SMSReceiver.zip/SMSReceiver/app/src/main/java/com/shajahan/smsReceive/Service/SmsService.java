package com.shajahan.smsReceive.Service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.shajahan.smsReceive.R;
import com.shajahan.smsReceive.Receiver.SmsReceiver;
import com.shajahan.smsReceive.View.Menu.MainActivity;

public class SmsService extends Service {

    private SmsReceiver smsReceiver;
    private static final int SERVICE_NOTIFICATION_ID = 123;


    @Override
    public void onCreate() {
        super.onCreate();
        smsReceiver = new SmsReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(smsReceiver, intentFilter);

        // Create a notification for the foreground service
        createNotificationChannel();
        Notification notification = createNotification();
        startForeground(SERVICE_NOTIFICATION_ID, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Service will be restarted if it's killed by the system
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (smsReceiver != null) {
            unregisterReceiver(smsReceiver);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "sms_service_channel_id",
                    "SMS Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class); // in main activity
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        return new NotificationCompat.Builder(this, "sms_service_channel_id")
                .setContentTitle("SMS Service")
                .setContentText("Listening for SMS messages")
                .setSmallIcon(R.mipmap.ic_launcher_foreground) // Replace with your app's icon
                .setContentIntent(pendingIntent)
                .build();
    }
}
