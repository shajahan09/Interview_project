package com.shajahan.smsReceive.View.SplashScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.shajahan.smsReceive.BuildConfig;
import com.shajahan.smsReceive.R;
import com.shajahan.smsReceive.View.Menu.MainActivity;

public class Splash_screen_Activity extends AppCompatActivity {
    private TextView jheaderText, jSplashAppVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen_activity);

        jSplashAppVersion = findViewById(R.id.splashAppVersion);
        jSplashAppVersion.setText(BuildConfig.VERSION_NAME);
      //  jheaderText = findViewById(R.id.header_title);
       // Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/fine_font.ttf"); // for fonts set
      //  jheaderText.setTypeface(typeface);


        new Handler().postDelayed(() -> {
            Intent i = new Intent(Splash_screen_Activity.this, MainActivity.class);
            startActivity(i);
            finish();
        }, 1000);
    }

}