package com.shajahan.smsReceive.Utils;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.shajahan.smsReceive.R;
import com.shajahan.smsReceive.ToolbarHandle;

public class ToolbarHelper {
    public static void configureToolbarActivity(Activity activity, String toolbarText, ToolbarHandle currentClass) {
        Toolbar toolbar = (Toolbar) activity.findViewById(R.id.toolBarID_global);
        TextView toolbar_Text =(TextView) activity.findViewById(R.id.toolbarText_global);
        toolbar_Text.setText(toolbarText);
        if (toolbar != null) { //credit to @Gabriele Mariotti, I missed this check
            toolbar.setElevation(0);
            toolbar.setTitle("abc....");

            ((AppCompatActivity) activity).setSupportActionBar(toolbar);
            toolbar.setNavigationIcon(activity.getResources().getDrawable(R.drawable.ic_back));
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentClass.toolbarBackArrow();

                }
            });
        }
    }
}
