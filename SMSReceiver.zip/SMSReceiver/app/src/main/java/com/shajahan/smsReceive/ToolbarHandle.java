package com.shajahan.smsReceive;

public interface ToolbarHandle {
    void toolbarBackArrow();
}
