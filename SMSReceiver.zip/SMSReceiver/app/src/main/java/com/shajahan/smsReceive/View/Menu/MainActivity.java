package com.shajahan.smsReceive.View.Menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.shajahan.smsReceive.R;
import com.shajahan.smsReceive.Service.SmsService;
import com.shajahan.smsReceive.ToolbarHandle;
import com.shajahan.smsReceive.Utils.ToolbarHelper;

public class MainActivity extends AppCompatActivity implements ToolbarHandle {
    private TextView number_tv, content_tv;
    private final int MY_PERMISSIONS_REQUEST_SMS = 101;

    private BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("sms_received".equals(intent.getAction())) {
                String sender = intent.getStringExtra("sender");
                String message = intent.getStringExtra("message");

                // Update the TextView with the received SMS
                number_tv.setText(sender);
                content_tv.setText(message);

                // Display a toast message if needed
                Toast.makeText(context, "SMS from: " + sender + "\nMessage: " + message, Toast.LENGTH_LONG).show();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Initialize the TextView
        number_tv = findViewById(R.id.number_tv);
        content_tv = findViewById(R.id.content_tv);


        // for toolbar
        ToolbarHelper.configureToolbarActivity(this, getString(R.string.home_title), MainActivity.this);

        // Request SMS permissions
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_SMS);

        // Start the SmsService
        startService(new Intent(this, SmsService.class));

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_SMS) {
            // Check if the user granted the SMS permission
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can now handle SMS reception
                Toast.makeText(this, "permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied, handle accordingly
                Toast.makeText(this, "permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register the BroadcastReceiver to listen for SMS updates
        IntentFilter intentFilter = new IntentFilter("sms_received");
        registerReceiver(smsReceiver, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the BroadcastReceiver when the activity is paused
        unregisterReceiver(smsReceiver);
    }

    @Override
    public void toolbarBackArrow() {
        finish();
    }
}